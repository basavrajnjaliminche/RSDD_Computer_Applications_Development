package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;

@Controller
public class StudentController {

	@Autowired
	private StudentRepository studentRepository;

	@GetMapping("/students")
	public List<Student> getAllEmployees() {
		return studentRepository.findAll();
	}

	@GetMapping("/students/{number}")
	public ResponseEntity<Student> getEmployeeById(@PathVariable(value = "id") Long studentNumber)
			throws Exception {
		Student student = studentRepository.findById(studentNumber)
				.orElseThrow(() -> new ResourceNotFoundException("Student not found for this id :: " + studentNumber));
		return ResponseEntity.ok().body(student);
	}

	@PostMapping("/students")
	public Student createEmployee(@RequestBody Student student) {
		return studentRepository.save(student);
	}
}
